Working on different things separately, therefore some info are segregated

Likely, 
	information regarding accounts/users manipulation is in Cameron's fill-auction file
	information regarding auctions (and manipulation) is in Richard's fill-auction file

Files in "/other-exports/" is just for safety in case and for convenience.