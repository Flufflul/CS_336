# 	CS336 Final Project
## 	Submission Information
### 2021 April 25

###	Group members:
		Geon Yeong Kim
		Richard Xu
		Zhengjie Dong
		Cameron Hoang

### Admin credentials:
		username: admin1
		password: adminpw

### Customer Representative credentials:
		username: rep1
		password: reppw